inv ver 1.10
Program for matrix inversion.

Example #1:
randmat(30,30)->amat
inv(amat):_asminfo

The answer is stored in the variable "_ASMINFO"
(thanks to TI idiots!)

Example #2:
inv([1,2;3,4]):_asminfo

Result :
[-2,1;1.5,-0.5]

The algorithm used for matrix inverse was the "Metodo ANA"
developed for Ing. Daniel Gomez Garcia
Saltillo, Coah, Mexico.
1985.

Thanks to Zeljko Juric and Doug Burkett!