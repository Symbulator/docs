// matriz.c
// Created 14/07/00; 10:08:13 a.m.
#include <nostub.h>
#include <all.h>
#include "matriz.h"
 
MatType dim(int NumRow, int NumCol)
{
    MatType matrix;
    int i, j;
  
    matrix= (MatType) malloc(NumRow * sizeof(PFloat));
    if (!matrix) return NULL;
    for (i=0; i<NumCol; i++) {
    		matrix[i]= (PFloat) malloc(NumCol * sizeof(ti_float));
    		if (!matrix[i]) {
    		   // free memory again because is useless
    		   for (j=i; j>0; j--) 
    		     free(matrix[j-1]);
    		   free(matrix);
    		   return NULL;
    		}
    }
    
    // init the matrix with zero.
    
    for (i=0; i<NumRow; i++)
       for (j=0; j<NumCol; j++)
          matrix[i][j] = ZERO;   
    return matrix; 
}

void delmat(MatType mat, int NumCol)
{
		int i;
  
    for (i=0; i<NumCol; i++)
       free(mat[i]);
    free(mat);
}
