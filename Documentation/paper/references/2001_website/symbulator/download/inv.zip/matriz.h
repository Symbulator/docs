// matriz.h
// Created 14/07/00; 10:43:54 a.m.

#ifndef MATRIZ
#define MATRIZ

typedef ti_float* PFloat;
typedef PFloat* MatType;

MatType dim(int NumRow, int NumCol);
void delmat(MatType mat, int NumCol);

#endif
