// getargs.h
// Created 13/07/00; 10:42:30 a.m.
#ifndef GETARGS
#define GETARGS

ti_float getfloat(ESI *argptr);
int getInt(ESI *argptr);

#endif
