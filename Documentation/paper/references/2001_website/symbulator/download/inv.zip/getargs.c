// getargs.c
// Created 13/07/00; 10:40:09 a.m.
#include <nostub.h>  // Make NoStub Program
#include <all.h>     // Include All Header Files
#include <timath.h>
#include "getargs.h"

ti_float getfloat(ESI *argptr) // converts an arg. to a float if it is an integer 
{
    switch (GetArgType(*argptr)) { 
     case FLOAT_TAG: return GetFloatArg(*argptr); 
     case POSINT_TAG: return flt(GetIntArg(*argptr)); 
     case NEGINT_TAG: return flt(-GetIntArg(*argptr)); 
     default: return NAN;
   }
}

int getInt(ESI *argptr)
{
  switch(GetArgType(*argptr)) { 
     case FLOAT_TAG: return trunc(GetFloatArg(*argptr)); 
     case POSINT_TAG: return GetIntArg(*argptr); 
     case NEGINT_TAG: return -GetIntArg(*argptr); 
     default: return 0;
   }
}
