// Inv.c v1.1
// Matrix Inverse Algorith "ANA"
//
// Created 14/07/00; 10:52:46 a.m.
// by Rafael H. Padilla V.
// dysup@hotmail.com
//
#define RETURN_VALUE _asminfo
#include <nostub.h>
#include <all.h>
#include "matriz.h"
#include "getargs.h"

int _ti89, _ti92plus;

int _main(void)
{
   MatType A, B, TEMP;
   int i,j,k;
   int NumRow, porciento=0, incremento;
   char msg[15];
   ti_float r, p;
   ESI argptr = NULL;
   
   InitArgPtr(argptr);
   if (!is_square_matrix(argptr)) return 0; //only square matrix.
   
   argptr--;
   NumRow = remaining_element_count(argptr); //num. of rows and cols.
   incremento = 100/NumRow;
   ST_showHelp("wait..."); 
 
   // create A and B matrix
   if (!(A = dim(NumRow, NumRow))) return 0;           
   if (!(B = dim(NumRow, NumRow))) {
     delmat(A, NumRow);
     ST_eraseHelp(); 
     return 0;
   }
   
   //take matrix A from the estack.
   for (i=0; i<NumRow; i++) {
      argptr--;
      for (j=0; j<NumRow; j++)
         A[i][j] = getfloat(&argptr);
      argptr--;
   }
   argptr--;
   
   ST_showHelp("Ready:   0%");
   // Inverse for "el metodo ANA."
   r = ONE;
   for (k=0; k<NumRow; k++) {
     p = A[k][k];
     for (j=0; j<NumRow; j++) {
       B[k][j] = fneg(A[k][j]);
       B[j][k] = A[j][k];
     }
     B[k][k] = r;
     for (i=0; i<NumRow; i++)
       for (j=0; j<NumRow; j++)
         if ((i!=k) && (j!=k))
           B[i][j] = fdiv(fsub(fmul(p,A[i][j]),fmul(A[i][k],A[k][j])),r);

     TEMP = A; A = B; B = TEMP;
     r = p;
   
     sprintf(msg,"Ready: %3d%%",porciento+=incremento);
     ST_showHelp(msg);   
   }
 
   // End of calc.
   
   //Free the memory of matrix B.
      delmat(B, NumRow);   
   
   // return answer to estack.
   push_END_TAG();
   for (i=NumRow-1; i>=0; i--) {
     push_END_TAG();
     for (j=NumRow-1; j>=0; j--)
       push_Float(fdiv(A[i][j],p));
     push_LIST_TAG();
   }
   push_LIST_TAG();
   
   //Free memory of matrix A.
   delmat(A, NumRow);   
   ST_eraseHelp(); 
    
   return 0;
}
