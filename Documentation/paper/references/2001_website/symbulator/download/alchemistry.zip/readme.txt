TI-89/92+ Al-Chemistry v2.0

Author: Alex Astashyn 
e-mail: simba@mad.scientist.com
Released: August 2000

Warning: was tested only on TI-89 HW1 AMS 2.04, 2.05 
but should work on any calc with any AMS version.

Intro:
	This fully featured chemistry package contains software designed to 
	perform variety of tasks, including: balancing chemical reactions of
	any complexity, calculating molar masses and percent compositions of
	chemical compounds, solving for required amounts of reactants and 
	products in stoichiometric calculations, performing various equilibrium 
	related calculations (determining reaction quotients and equilibrium
	constants, solving for unknown concentrations, predicting equilibrium-
	state concentrations from initial conditions). Interactive chemical wizard 
	allows to solve for any unknown variable from a database of chemical 
	equations, covering atomic structure (radioactive decay, relationships 
	between wavelength, frequency, momentum, etc); all gas laws (Charles' 
	Boyle's, Gay-Lussac's Avogadro's, ideal gas law, real gas law, combined
	gas law, density, root-mean-square velocity, KE per molecule, KE per mole,
	effusion rates, gaseous equilibrium); solutions (molarity, molality, 
	% by mass, % by volume, freezing point depression, boiling point elevation, 
	osmotic pressure); electrochemistry (definition of current, Nernst 
	equation); acids and bases (titrations, relationships between pH, pOH, 
	[H+], [OH-], Ka, pKa, Kb, pKb); thermochemistry (relationships between 
	free energy change, entropy, enthlapy, reduction potential, heat, specific
	and molar heat capacities). All programs should work on any HW and any AMS.
	No shells or kernels required.
	
	Bug reports, suggestions, and other comments are welcomed.

History:
	v2.0 - Added chemical solving wizard.
	     - Added equilibrium solver.
	     - Added chembal's ability to return answer as list of signed 
		coefficients for later use in equilibrium solver.
	v1.0 - Initial release.

Thanks to:
	TI-GCC team for the compiler.
	Zeljko Juric for the library and personal help.
	Rusty Wagner for the VTI.
	Lars Frederiksen and Rafael H. Padilla V. for consulting.

General notes:
	All programs (except ChemWiz) require arguments to run 
	and return values in the history area, so the result can be used 
	in further calculations. I purposedly did not include any user inerfaces, 
	welcome screens, dialogs and such, because I find the function based 
	interface more functional (pun was not intended). 

	If a program is executed without any arguments, the user 
	will be presented short on-screen instructions on how to use the program.

1. ChemBal v3.1 - Chemical Eqiation Balancer
--------------------------------------------

	This program balances chemical equations.

	Since this program is written in C, it is much faster than BASIC analogs. 
	Here are some benchmarks: 
	Time taken to balance 
		"Mn(NO3)2 + NaBiO3 + HNO3 -> HMnO4 + Bi(NO3)3 + NaNO3 + H2O" 
		on TI-89 HW 1 AMS 2.05:

		Chemistry Solver v3.01 - 57.5 sec.
		ChemBal v2.0           - 29.3 sec.
		ChemBal v3.1           - 3.1  sec.

	The numbers speak for themselves.
 
	ChemBal v3.1 is able to balance any chemical equations including REDOX. 
	It is not limited to a fixed number of elements or compounds you can use.

	General Syntax:
		chembal("Unbalanced_Equation" [,flag]) => "Balanced_Equation"
		(Note that the equation must be in quotes.)
		Usage of flags will be described below.

	Compound Synax:
		Elements are written in traditional form: Fe, Ca, S...
	 	Case is important. 'AB' is treated as two elements, but 'Ab' as one.
		Subscripts are normal numbers.
		You can use parentheses "(" and ")". Multiple occurrences and 
		hierarchies of parentheses are supported. 
		Do not use [brackets] or {curly braces} 

	Equation Syntax:
		"compound1+compound2+compound3->compound4+compound5"
		 where "->" is the STO character. (You can also use "=" instead).

	There are four types of answer Chembal v3.0 can give you.
	a) flag = 0 or no flag
		EG: chembal("Al(OH)3+H2S=Al2S3+H2O")
		return answer in traditional form:
		"<2>Al(OH)3+<3>H2S=<1>Al2S3+<6>H2O"
	b) flag = 1
		EG: chembal("Al(OH)3+H2S=Al2S3+H2O",1)
		return answer as a list of unsigned integers:
		{2, 3, 1, 6}
		This is useful if you want to have direct access to the coefficients.
		(Calculating sum of the coefficients and such...)
	c) flag = 2
		EG: chembal("Al(OH)3+H2S=Al2S3+H2O",2)
		return answer as a list of signed integers:
		{-2, -3, 1, 6}
		This is useful for equlibrium calculations, because the equilibrium
		slover requires such list as one of the arguments.
	d) flag = 3
		EG: chembal("H2+N2+O2->NH3+H2O",3)
	    	return answer in terms of arb. constants:
		{2*@2, 2*@1, -(3*@1 - @2), 4*@1, -2(3*@1 - @2)}
		This is an advanced feature that allows recognition of 
		multiple independent reactions.
		In the example above, the two arbitrary constants @1 and @2 indicate 
		two independent reactions. By substituting different values for the 
		constants, you will obtain linearly independent sets of coefficients. 
		(Don't get scared if you don't know what the hell is going on, 
		they don't teach that in high schools).

	Notes on waters of hydration and crystals:	
		Waters of hydration are not supported. If you have to deal with one, 
		you can easily rewrite it as a regular compound. 
		Example: CuSO4 o 3H2O can be rewritten as CuSO4(H2O)3

	Notes on REDOX equations:
		Charges are written after the carot "^".
		Positive charges are normal numbers.
		Negative charges are negated numbers.
		Examples:
			Sulfate ion: SO4^-2
			Ammonium ion: NH4^1
			Hydroxide ion: OH^-1
			Copper II ion: Cu^2
		Add OH^-1 to the left side of the equation and H20 to the right side, 
		if the reaction occurs in basic medium.
		Add H^1 to the left side of the equation and H20 to the right side, 
		if the reaction occurs in acidic medium.


2. MolMass v1.0 - Molar Mass Calculator
---------------------------------------

	This program calculates molar masses of the compounds.

	Consider a standard procedure for calculating molar mass of Ca3(PO4)2:
		1) Look up the mass of Oxygen in a Periodic Table.
		2) Multiply that by 4.
		3) Look up the mass of Phosphorus in a Periodic Table.
		4) Add that to the mass of Oxygen.
		5) Multiply that by 2.
		4) Look up the mass of Calcium in a Periodic Table.
		5) Multiply that by 3.
		6) Add to the stuff calculated before.
	
	Consider a standard procedure for calculating molar mass of Ca3(PO4)2
	using MolMass:
		1) molmass("Ca3(PO4)2")

	General Syntax:
		molmass("Compound" [,flag]) => Molar_mass
		(Note that the compound must be in quotes.)
		Usage of flags will be described below.

	Compound Synax:
		Elements are written in traditional form: Fe, Ca, S...
	 	Case is important. 'AB' is treated as two elements, but 'Ab' as one.
		Subscripts are normal numbers.
		You can use parentheses "(" and ")". Multiple occurrences and 
		hierarchies of parentheses are supported. 
		Do not use [brackets] or {curly braces} 
		(Yes, I did copy'n'paste it.)

	There are two tasks that MolMass can perform
	a) Calculate molar mass (no flag)
		EG: molmass("Ca3(PO4)2") 
		retruns 310.177
	b) Calculate percent composition of the compound (flag = 1)
		Example: molmass("Ca3(PO4)2",1) 
		returns
			[["O"  .4127]
			 ["P"  .1997]
			 ["Ca" .3876]]
		Note that answer is given in ratios. Multiply that by 100 to get %.

3. StoiSlv v1.0 - Stoichiometric Solver
---------------------------------------

	This simple yet useful program calculates required quantities of chemical 
	compounds in a reaction where the quantity of one compound is known.

	General syntax:
		stoislv(list, index, val)
		list: list of unsigned coefficients of a balanced chemical equation
			(Like one produced by chembal with flag = 1)
		index: the number of the reference compound in the list.
		val: the quantity of the the reference compound (moles)

	Example 1:
		Consider reaction: "Al(OH)3+H2SO4->Al2(SO4)3+H2O"
		If there are 2.7 moles of H2SO4, calculate the required quantity 
		of Al(OH)3 and quantities of Al2(SO4)3 and H2O produced.

		List of the unsigned coefficients is {2, 3, 1, 6}
		Index of the reference compound, H2SO4, is 2
		Quantity of the reference compound is 2.7
		
		stoislv({2, 3, 1, 6}, 2, 2.7) returns {1.8, 2.7, .9, 5.4}

		Therefore, 2.7 moles of H2SO4 requires 1.8 moles of Al(OH)3 and
		produces .9 moles of Al2(SO4)3 and 5.4 moles of H2O.

		Of course, if you had to deal with masses, solutions, or gases,
		you would have to convert everything to moles first.
	
	Example 2: (limiting reactant problem)
		Consider reaction: "H2C2O4 + K2MnO4 -> CO2 + K2O + Mn2O3 + H2O"
		There are 6.3 moles of H2C2O4 and 3.7 moles of K2MnO4.
		Calculate quantities of all compounds after the reaction.

		List of the coefficients is {3, 2, 6, 2, 1, 3}
		Index of the reference compound, H2C2O4, is 1
		Quantity of the reference compound is 6.3

		stoislv({3, 2, 6, 2, 1, 3}, 1, 6.3) returns 
		{6.3, 4.2, 12.6, 4.2, 2.1, 6.3}

		Therefore, 6.3 moles of H2C2O4 require 4.2 moles of K2MnO4.
		However, we have only 3.7 moles of this stuff. Then, its gotta be
		the limiting reactant.

		Run the program with respect to the K2MnO4:

		List of the coefficients is {3, 2, 6, 2, 1, 3}
		Index of the reference compound, K2MnO4, is 2
		Quantity of the reference compound is 3.7

		stoislv({3, 2, 6, 2, 1, 3}, 2, 3.7) returns 
		{5.55, 3.7, 11.1, 3.7, 1.85, 5.55}

		Quantity of H2C2O4 left: 6.3 - 5.55 = .75 moles.
		Quantity of K2MnO4 left: 3.7 - 3.7 = 0 moles. (limiting reagent)
		Quantity of CO2 produced: 11.1 moles.
		Quantity of K2O produced: 3.7 moles.
		Quantity of Mn2O3 produced: 1.85 moles.
		Quantity of H2O produced: 5.55 moles.

1. EquiSlv v1.0 - Equilibrium solver
------------------------------------
	This utility is for solving equilibrium problems. 

	There are three tasks that EquiSlv can perform
	a) Calculate equilibrium constant (or reaction quotient) of
	   a system.
		Syntax: 
			equislv(list1, list2)
			list1: list of the concentrations of the compounds.
			list2: list of the corresponding signed coefficients.
				(like one returned by chembal with flag = 2). 

		Example: 
			consider system H2 + N2 <=> NH3
			[H2] = 2 mol/l
			[N2] = 3 mol/l
			[NH3] = 6 mol/l
			Find the reaction quotient of the system.
			
			List of concentrations: {2, 3, 6}
			List of signed coefficients: {-3, -1, 2}

			equislv({2, 3, 6}, {-3, -1, 2})
			returns 1.5

	b) Predict the equilibrium state concentrations from initial conditions.
		If you are familiar with this task, you know that it is major pain in the
		ass. The equations are virtually impossible to solve by hand and one has 
		to drop terms, simplify stuff and such. After that, one has to find the right
		roots, and at the end the result must be checked for validity.
		EquiSlv generates all necessary eqations, and solves them numerically
		without dropping any terms using the built in numerical solver, thus, giving
		the most precise answer that can be obtained in just several seconds.
		(Developing algorithm and writing code for this part was THE pain).
		
		Syntax: 
			equislv(list1, list2, K)
			list1: list of the initial concentrations of the compounds.
			list2: list of the corresponding signed coefficients.
				(like one returned by chembal with flag = 2).
			K: equilibrium constant 

		Example:
			consider system H2 + N2 <=> NH3
			[H2] = 2.0 mol/l
			[N2] = 3.0 mol/l
			[NH3] = 6.0 mol/l
			K = .0015625
			Find the equilibrium-state concentrations.

			List of concentrations: {2, 3, 6}
			List of signed coefficients: {-3, -1, 2}
			
			equislv({2, 3, 6}, {-3, -1, 2}, .0015625)
			returns {8., 5., 2.}

			Therefore, the concentrations of the compounds at equilibrium are:
			[H2] = 8.0 mol/l
			[N2] = 5.0 mol/l
			[NH3] = 2.0 mol/l

			You can check the answer by calculating what would be the 
			equilibrium constant of the system it this state:
			equislv({8, 5, 2}, {-3, -1, 2})
			returns .0015625 which we know to be true.

			Note that the answer is stoichiometrically correct: 4 moles of NH3
			decompose producing 6 moles of H2 and 2 moles of N2. That leaves 
			6 - 4 = 2 moles of NH3 and makes 2 + 6 = 8 moles of H2 and 
			3 + 2 = 5 moles of N2. Isn't that kewl?

			In the actual problems you won't get such nice answer. 
			In this example, I made up the value of K = .0015625 so the
			answer would look good.

			(On the screenshot, you can see the visualization of the Harber
			process graphed with respect to Exp(Q), where the bold line 
			indicates the total amount of gas).


	c) Calculate a concentration of a compound of a system at state.
		Syntax:
			equislv(list1, list2, Q, n)
			list1: list of the initial concentrations of the compounds.
			list2: list of the corresponding signed coefficients.
				(like one returned by chembal with flag = 2).
			Q: reaction quotient (or equilibriom constant)
			n: coefficient corresponding to the unknown concentration.

		Example:
			consider system H2 + N2 <=> NH3
			[H2] = 2 mol/l
			[NH3] = 6 mol/l
			K = 1.5
			Find the concentration of N2

			List of concentrations: {2, 6}
			List of signed coefficients: {-3, 2}
				IMPORTANT: the "regular" set of signed coeeficients would look 
				like {-3, -1, 2}, but since the concentration of N2 was 
				not included in the list of concentrations, the coefficient 
				of N2 is not included in the list of the coefficients. 
			K = 1.5
			Signed coefficient corresponding to the unknown concentation: -1
			
			equislv({2, 6}, {-3, 2}, 1.5, -1)
			returns 3.

			Therefore, [N2] = 3 mol/l 
			(Note that the state of the system is the same as in example a).

1. ChemWiz 1.0 - Chemical Equation Solving Wizard
-------------------------------------------------
	
	This is an interactive chemical solver that allows the use of units.

	(I'm fu#%ing tired of writing all this bull$#t now, so I will be concise).
	
	Usage:
		Select the topic; 
		Select the equation; 
		Select the unknown variable; 
		Plug-in known variables; 
		Get the damn answer.

DISCLAIMER
---------- 
	THE SOFTWARE IS PROVIDED "AS-IS." THERE ARE NO WARRANTIES OF ANY KIND, EXPRESS OR 
	IMPLIED, INCLUDING, BUT  NOT LIMITED TO, WARRANTIES OF MERCHANTABILITY AND 
	FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL THE AUTHOR BE LIABLE TO ANY 
	PARTY FOR DIRECT, INDIRECT, SPECIAL OR OTHER  CONSEQUENTIAL OR INCIDENTAL DAMAGES 
	ARISING DIRECTLY OR INDIRECTLY FROM THE USE OF THE SOFTWARE, INCLUDING BUT NOT 
	LIMITED TO ANY LOST PROFITS, BUSINESS INTERRUPTION, SOFTWARE OR HARDWARE 
	CORRUPTION.

DISTRIBUTION:
------------
	THE SOFTWARE MAY DE DISTRIBUTED FOR FREE ONLY.

	


		 





