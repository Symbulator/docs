Incidence Matrix Tools
�������������������������

This is a BASIC program to work with the calculations related to incidence matrix of a circuit (the kind of calculations performed in Chapter 7.5 of Grainger/Stevenson Power System Analysis book).

First store three matrices in variables...
1) A, I, Zpr      ...or...
2) A, V, Zpr      ...or...
3) A, I, Ypr      ...or...
4) A, V, Ypr      ...or...
...and run IMT. The program calculates the all the other matrices (Z, Y, I, V, A, Atransverse, Zpr, Ypr, Ipr and Vpr)

Enjoy!

Roberto Perez-Franco
Perez-Franco@iname.com
March 13, 1999.

This software is part of the EE*Pack.
Get the latest EE*Pack at http://scs.ticalc.org

Engineers should always work for peace, never for war.
Change the rules. Join PAX. http://w3.to/pax