Power Tools Plug-In for Symbulator v 0.92
for Symbolic Circuit Simulator
by Roberto Perez-Franco @ May 14, 2000.

Power tools (powerscs.89g)

Read documentation online at http://scs.ticalc.org

Archiving Power Tools Plug-In files on TI-89 and TI-92+

After loading the powerscs.89g to your calculator, run the powerarc() program. It will prepare and archive plug-in files in your ROM. Just execute following command from the command line:

scs/powerarc()

The install program powerarc() can be deleted after installation. Keep it if you plan to pass the program to a friend using the linking cable.

You are invited you join PAX, which is a pacifist movement for engineers. Engineers should always work for peace, never for war. Change the rules - Join PAX. http://pax.w3.to

Symbolic Circuit Simulator, Symbulator, the program's code, algorithm and logo are (c) Roberto Perez-Franco 1999-2000