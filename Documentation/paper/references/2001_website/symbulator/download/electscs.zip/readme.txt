Elect SCS Plug-In for Symbolic Circuit Simulator 0.4
for TI89/TI92+ calculators with AMS 1.05
by Roberto Perez-Franco @ September, 1999.

Electronic tools (electscs.89g)

SCS documentation is huge, thus it is not included here. You have to read it online at http://scs.ticalc.org/ti89/scs/ (here you can also get the latest SCS and several other nice tools of the EE*Pack). Visit it often, for new upgrades and examples of SCS uses are placed frequently.

Share SCS with your classmates! If you use SCS, please let me know. Send me an email at user@scs.ticalc.org and tell me what you think of SCS, along with your name, major, college and all that stuff.

As a SCS user, you are invited you join PAX, which is a pacifist movement for engineers. Engineers should always work for peace, never for war. Change the rules - Join PAX. http://pax.w3.to

Symbolic Circuit Simulator, Symbulator & SCS names, the program's code, algorith and logo are
(c) Roberto Perez-Franco 1999