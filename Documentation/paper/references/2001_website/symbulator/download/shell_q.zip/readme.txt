SCS-Shell V1.51 by Kamil Malinski
E-Mail: mjfox@rocketmail.com
ICQ: 29148030


Description:

This is a shell for Roberto Perez-Franco's Symbulator (SCS). It is NOT a standalone program; Symbulator and DiffEq have to be on your calc (in their respective folders). This shell allows you to edit the circuit matrix which is necessary to perform analysis with SCS.
Download the Symbulator at http://scs.calc.org


Installation:

Send the group file (shell.89g) to your calc and run the archive-utility by typing "scsshell\archive()" on the home screen (assuming it is in the scsshell-folder). After that you are ready to start the shell by typing "scsshell\shell()".

I think the program is self-explaining - just try it. There is a help available in the program - press [APPS] (on the main-screen), choose "more..." -> "help".


Keys:

[APPS]: menu
[CATALOG]: add element
[ENTER]: edit element
[<-]: delete element
[MODE]: start SCS
[ESC]: exit shell
[HOME]: save state & switch to home screen (new!)
arrow up/down: scroll up/down
arrow right: view element


Please send me your comments. What do you think about it? Is it usefull? What shall I add, change, ...?

Note for v1.0 - V1.42: this versions were written for "Symbulator beta12" but it also may work with older and newer versions (but NOT with "Symbulator Q"). Write me an e-mail if you need an older version of my shell.

Note for v1.51: this version was written for "Symbulator Q" but it also may work with newer versions


History:
14-5-01 - V1.51
- Thevenin and Ports didn't work, this is fixed now!

11-5-01 - V1.5
- support for Symbulator Q! if you want to use an older version of the Symbulator (why you should?) you have to use V1.42 of the Shell! This version is ONLY for Symbulator Q!

28-3-00 - V1.42
- fixed a bug in the "delete element" - routine (credits go to Roberto Perez Franco)
- fixed a bug in the "view element" - rountine (credits go to Reinhard H.)
- because of a bug in the TI-OS the shell crashed randomly. The bug occurs when a program calls an archived function or sub-program. That's why the shell now unarchives every sub-program on the start and asks you if you want to archive everything again on exit.
- renamed the archive-utility from "runme" to "archiver" (that is a better name for it)

19-3-00 - V1.41
- added the ability to scroll the results to the left and right from the "view voltage" - function

18-3-00 - V1.4
- it seems that the TI89 have problems with large programs - bacause of that I had to split the shell into parts. The shell consists of several modules now. You find everything in a folder called "SCSSHELL".
- added support for BiPorts! Yes, I know, this took a while but it was not as easy as it sounds :-).
- added a nice feature: you can switch to the home screen by pressing "HOME". The next time you start the shell everything will be as it was. This is nice if you have to do any calculations concerning the circuit "by hand". With the new feature this is not a problem any more. Note: do not delete any variables in the SCSTEMP-folder while in "home screen"-mode. This could confuse the shell. 
- addad an archive-utility (runme.89p)
- optimized the code: the shell is a little bit faster now
- removed the "change folder"-feature: I think this feature was really unnecessary
- now the shell removes the SCSTEMP-folder if it is empty - Reinhard, I hope you are satisfied now ;-)

27-2-00 - V1.32
- I found and killed a small bug in the "start SCS..." - "AC-Analysis" - routine
- added the ability to scroll the results to the left and right (usefull if the results are to long for the screen)

19-2-00 - V1.31
- I found and killed a stupid bug in the "view voltage" - function

12-2-00 - V1.3
I changed a lot of things. First of all the bad news:
- sorry, still no support for Bi-Ports
- the shell grew again (about 25Kb now)
now the good news:
- The shell perceives now if SCS-Calculations were a success or not
- The shell also supports symbolic node names now
- previously the shell was not able to display large results (especially when there were symbolic), now the shell tries to show the results in a dialog box and if this is not possible it switches to an other display mode where you can scroll through the results
- the shell asks you if you want to keep the variables created by SCS and is able to delete them for you
- a LOT OF bugs were killed

30-12-00 - V1.2
- implemented the "theve"-tool
- once again reduced the size of the shell (about 10% smaller than V1.1 although the "theve"-tool is a now implemented)

29-12-00 - V1.1
- added ability to view ALL voltages in the circuit
- reduced the size of the shell (about 25% smaller than V1.05)
- fixed some small bugs

28-12-00 - V1.05: 
- fixed a bug in the "delete element" routine (thanks to my friend Reinhard H.)

27-12-00 - V1.0:
first public release

many thanks to:
Roberto Perez-Franco (for his great Symbulator and his support)
Reinhard H. (for beta testing and many comments)
Rusty Wagner (for his great Virtual-TI)

Symbulator is (c) Roberto Perez-Franco 1999.