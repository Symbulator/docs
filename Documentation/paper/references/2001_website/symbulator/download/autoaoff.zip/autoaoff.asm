;Auto Alpha-Lock Off
;Copyright (C) Kevin Kofler, 2000-2001
;please read the readme file before using this file
;Please DO NOT distribute modified versions without my
;permission!

;A note for beginners:
;*** COMMENTS, LABELS AND VARIABLE NAMES WILL _NOT_   ***
;*** APPEAR ON THE CALCULATOR, SO I CAN USE _LONG_    ***
;*** NAMES OR COMMENTS AND 2 LABELS AT THE SAME PLACE ***
;*** _WITHOUT_ INCREASING THE FILE SIZE !             ***

  include "OS.h" ;You need the version included with TeOS
                  ;(because of the ROM_CALL2 macro).
                  ;If you want to use the TI-GCC IDE,
                  ;you have to copy this file to the
                  ;TI-GCC\ASM\INCLUDE folder (replacing the
                  ;older version given with TI-GCC).
  xdef _nostub ;no kernel required
  xdef _ti89 ;This is only for the TI-89.
  xdef _main ;This is a program, not a library.

_main:
  include "h220xtsr.h"
  movem.l a0-a6/d0-d7,-(a7) ;save all registers
  ROM_CALL2 cmd_table ;get the location of the command table
  cmp.l #$400000,a4 ;check if TI-92+
  bcc ti92plus
  pea.l prodIDbuf(PC) ;routine for TI-89
  ROM_CALL AB_prodid ;get AMS version
  addq.l #4,a7
  cmp.b #'0',AMSversion ;check if 1.00
  beq ams1 ;display error message for AMS 1
  cmp.b #'3',AMSversion ;check if 1.05
  beq ams1 ;display error message for AMS 1
  cmp.b #'5',AMSversion ;check if 2.01
  bne not201
  move.l #$79b1,alphalock ;adjust addresses
  move.l #$4166,wrongpos
  bra amsok
not201:
  cmp.b #'6',AMSversion ;check if 2.02
  beq is202
  cmp.b #'7',AMSversion ;check if 2.03
  bne not203
is202:
  move.l #$79b5,alphalock ;adjust addresses
  move.l #$4166,wrongpos
  bra amsok
not203:
  cmp.b #'8',AMSversion ;check if 2.04
  bne not204
  move.l #$6499,alphalock ;adjust addresses
  move.l #$4162,wrongpos
  bra amsok
not204:
  cmp.b #'9',AMSversion ;check if 2.05
  bne amsnotok
  move.l #$649d,alphalock ;adjust addresses
  move.l #$4162,wrongpos
amsok: ;compatible AMS version
  ROM_CALL2 EV_hook ;get the location of the event hook
  move.l (a4),oldevent ;save the old event hook and call
                       ;it from the event routine
  move.l #(endevent-newevent),-(a7)
  ROM_CALL HeapAllocHigh ;allocate a handle for the new
                         ;event routine
  addq.l #2,a7
  tst.w d0 ;check if NULL handle
  beq nomem ;if yes, display "no mem" error message
  move.w d0,(a7)
  ROM_CALL HeapDeref ;get ("dereference") the address
  move.l a0,a3 ;save the address to a3 for further use
  subq.l #2,a7
  move.l #(endevent-newevent),(a7)
  pea.l newevent(PC)
  move.l a0,-(a7)
  ROM_CALL memcpy ;copy the event routine to the handle
  lea.l 12(a7),a7 ;shorter as add(a).l #12,a7
  ROM_CALL2 EV_hook ;get the location of the event hook
  add.l #$40010,a3 ;add: - $40000 for HW2 AMS 2.0x without
                   ;       HW2Patch
                   ;     - $10 to skip the uninstall
                   ;       information (need the start of
                   ;       the executable code here)
  move.l a3,(a4) ;install the event hook
  pea.l installedST(PC) ;show "installed" message
showmsg:
  ROM_CALL ST_helpMsg
  addq.l #4,a7
  movem.l (a7)+,a0-a6/d0-d7 ;restore all registers
  rts ;return
amsnotok: ;some unknown AMS version (common for 89 and 92+)
  pea.l amsnotokST(PC) ;display "Incompatible AMS
  bra showmsg          ;version"
ams1: ;display an error message on AMS 1
  pea.l ams1ST(PC) ;(no auto-alpha-lock to disable on AMS 1)
  bra showmsg
ti92plus: ;display an error message on a TI-92+
  pea.l ti92plusST(PC) ;(no alpha-lock to disable on a TI-92+)
  bra showmsg
nomem:
  addq.l #2,a7 ;adjust the stack
  pea.l nomemST(PC) ;show "no mem" message
  bra showmsg
prodIDbuf: dc.b "00-0-"
AMSversion: dc.b "0-00",0
installedST: dc.b 'Auto',128,'Off 1.04 by Kevin Kofler installed',0
ams1ST: dc.b 'ERROR: no auto-',128,'lock to disable on AMS1',0
amsnotokST: dc.b 'ERROR: incompatible AMS version',0
nomemST: dc.b 'ERROR: not enough memory',0
ti92plusST: dc.b 'ERROR: no alpha-lock to disable on a TI-92+',0

  EVEN ;avoid silly alignment problems
       ;("Address Error" etc.)

newevent: ;event hook
  dc.b 'evHkAuto',128,'Off' ;signature "evHk" + program name
                      ;(for event hook uninstaller)
oldevent: dc.l 0 ;placeholder for old event hook
                 ;0 if none
                 ;placed here for easier and
                 ;program- and version-independent
                 ;uninstalling
  movem.l a0-a6/d0-d7,-(a7) ;save all registers
  move.l 64(a7),a2 ;a2=event structure address (a2 for TEOS)
  lea.l useralpha(PC),a5 ;(a5) = "user alpha-lock" flag
  cmp.l wrongpos(pc),a2 ;check if in a dialog
  beq notalpha ;if not, do nothing
  cmp.w #$710,(a2) ;check if CM_KEYPRESS
  bne notkeypress ;if not, proceed
  cmp.w #278,10(a2) ;check if Catalog
  beq useralphaon ;if yes, turn on the "user alpha-lock"
                  ;flag
  ;Check if the user pressed alpha-lock here:
  btst.b #5,7(a2) ;if yes, check status flags for alpha-lock
  beq useralphaoff ;if off, turn off the "user alpha-lock"
                   ;flag
useralphaon:
  move.b #1,(a5) ;turn on the "user alpha-lock" flag 
  bra notalpha ;do nothing more
notkeypress:
  ;Disable the "user alpha lock" if we are exiting a dialog
  ;or a sequence of dialogs here:
  cmp.w #$760,(a2) ;check if CM_WPAINT
  bne notrepaint ;if not, proceed
useralphaoff:
  clr.b (a5) ;if yes, turn off the "user alpha-lock" flag
  bra notalpha ;do nothing more
notrepaint:
  cmp.w #$700,(a2) ;check if CM_IDLE
  bne notalpha ;if not, do nothing
  move.w 6(a2),d0 ;d0 = status flags
  and.w #$a420,d0 ;mask out all annoying mode indicators
  cmp.w #$a420,d0 ;check status flags for auto alpha-lock
  ;This is in fact the status flag for "status line text on
  ;and changed and alpha-lock on". Thus the checks for:
  ;- if we are in a dialog
  ;- if alpha-lock is on because the user pressed it in the
  ;  same dialog (and the status line text has changed due
  ;  to the navigation in the dialog)
  bne notalpha ;if not, do nothing
  tst.b (a5) ;check if the user has activated alpha-lock in
             ;this dialog
  bne notalpha ;if yes, do nothing
  move.l alphalock(PC),a3 ;get (AMS-dependent) address of
  clr.b (a3)              ;alpha-lock and turn it off
  clr.w -(a7)
  ROM_CALL ST_modKey ;adjust the status flag: * of the AMS
  addq.l #2,a7
  bclr.b #5,7(a2) ;               * of the event structure
notalpha:
  move.l oldevent(PC),a0 ;a0 = old event hook
  cmp.l #0,a0 ;check if 0 (tst refuses this addressing mode)
  beq nooldevent ;if 0 do nothing
  move.l a2,-(a7) ;pass event structure as an argument
  jsr (a0) ;run the old event hook
  addq.l #4,a7
nooldevent:
  movem.l (a7)+,a0-a6/d0-d7 ;restore all registers
  rts ;return
useralpha: dc.b 0
  EVEN ;avoid silly alignment problems
       ;("Address Error" etc.)
alphalock: dc.l $649d ;position of the alpha-lock status
                      ;may be adjusted for different AMS
                      ;versions
wrongpos: dc.l $4162 ;position of the event structure if NOT
                     ;in a dialog
endevent:

  END
