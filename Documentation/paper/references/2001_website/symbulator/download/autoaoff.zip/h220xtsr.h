;TI-89/92+ Hardware 2.00 AMS 2.0x TSR support v.1.02 HEADER FILE VERSION
;Copyright (C) Kevin Kofler, 2001
;Just include this after your _main: entry point and then continue your
;program as normally. And please don't accuse me of wasting a few bytes,
;I do this to make the including as simple as possible.
;You will also have to include "OS.h". You need the version included with
;TeOS (because of the ROM_CALL2 macro) except if you are using TI-GCC
;versions newer than 0.9, since I have asked for this macro to be included
;in their version of "OS.h". If you want to use the TI-GCC IDE, you have
;to copy this file to the TI-GCC\ASM\INCLUDE folder (replacing the older
;version given with TI-GCC).
;Do not use jmp or jsr instructions to labels in your program. Use bra or
;bsr instead!
;please read the readme file before using this file
;Please DO NOT distribute modified versions without my permission! Just
;include it as is and it should work.
;There is also a binary version of this include file if you cannot get it
;to work in source form.

 movem.l a0-a6/d0-d7,-(a7) ;save all registers
;detect the hardware version
;Thanks to Julien Muchembled for the C version listed in the TI-GCC FAQ.
;Converted to assembly by Kevin Kofler
 move.l $c8,d0
 and.l #$600000,d0 ;get the ROM base
 move.l d0,a0
 move.l 260(a0),a1 ;get the pointer to the hardware parameter block
 add.l #$10000,a0
 cmp.l a0,a1 ;check if the hardware parameter block is near enough
 bcc h220xtsr_skip ;if it is too far, it is HW1
 cmp.w #22,(a1) ;check if the parameter block contains the hardware version
 bls h220xtsr_skip ;if it is too small, it is HW1
 cmp.l #2,22(a1) ;check the hardware version
 bne h220xtsr_skip ;if not 2, it is HW1 (or an unknown hardware version)
;end of hardware version detection routine
 move.l $c8,a0
 cmp.l #1000,-4(a0) ;check if more than 1000 entries
 bcs h220xtsr_skip ;if no, it is AMS 1.xx
 ROM_CALL2 EX_stoBCD
 tst.w 92(a4) ;check for HW2Patch (ROM resident)
 beq h220xtsr_skip ;if it is installed, refuse installation
 cmp.l #$200000,$ac ;check if trap #$b points to the ROM
 bcs h220xtsr_skip ;if no, it (or RAM resident HW2Patch) is already installed
 bsr h220xtsr_enter_ghost_space ;unprotect and enter the ghost space
 move.l $ac,h220xtsr_oldtrapb ;save the old trap #$B and call it from the new one
 move.l #(h220xtsr_endtrapb-h220xtsr_newtrapb),-(a7)
 ROM_CALL HeapAllocHigh ;allocate a handle for the new trap #$B
 addq.l #2,a7
 tst.w d0 ;check if NULL handle
 beq h220xtsr_nomem ;if yes, display "no mem" error message
 move.w d0,(a7)
 ROM_CALL HeapDeref ;get ("dereference") the address
 move.l a0,a3 ;save the address to a3 for further use
 subq.l #2,a7
 move.l #(h220xtsr_endtrapb-h220xtsr_newtrapb),(a7)
 pea.l h220xtsr_newtrapb(PC)
 move.l a0,-(a7)
 ROM_CALL memcpy ;copy the trap #$B routine to the handle
 lea.l 12(a7),a7 ;shorter as add(a).l #12,a7
 add.l #$40008,a3 ;add: - $40000 for HW2 AMS 2.0x without
                  ;       HW2Patch
                  ;     - $8 to skip the uninstall
                  ;       information (need the start of
                  ;       the executable code here)
 move.l a3,$400ac ;install the trap #$B
 bra h220xtsr_skip
h220xtsr_nomem:
 pea.l h220xtsr_nomemST(PC) ;show "no mem" message
 ROM_CALL ST_helpMsg
 addq.l #6,a7
 movem.l (a7)+,a0-a6/d0-d7 ;restore all registers
 rts ;return

;Thanks to Zeljko Juric for this one! (slightly adapted to fit my needs)
h220xtsr_enter_ghost_space:
 lea -20(a7),a7              ; make some space on stack
 move.l #$3E000,a3          ; prepare area at $3E000 for unprotecting
 move.w (a3),-(a7)          ; save four bytes at $3E000, because small
 move.l 2(a3),-(a7)         ;   link code will be formed there
 move.l $C8,d0              ; TIOS jump table in d0
 andi.l #$600000,d0         ; =$200000 for TI89, =$400000 for TI92+
 addi.l #$20000,d0          ; now d0 points somewhere in TIOS
 move.l d0,12(a7)           ; fool the routine to believe that it is
 move.l d0,16(a7)           ;   called somewhere from TIOS
 trap #$C                   ; this trap only enters supervisor mode
 move.w #$2700,sr           ; disable ints
 move.l #$F,d3              ; prepare for calling trap #$B indirectly
 move.l a3,-(a7)            ; push $3E000 on the stack (new PC)
 clr.w  -(a7)               ; push 0 on the stack (new SR)
 lea h220xtsr_nx(pc),a0     ; put the address of label "nx" in a0
 adda.l #$40000,a0          ; add $40000 to make it "ghost"
 move.w #$4EF9,(a3)         ; this and the following instruction
 move.l a0,2(a3)            ;   create "jmp nx+40000" at $3E000
 move.l $AC,a0              ; the vector for trap #$B
 jmp (a0)                   ; enter into trap #$B indirectly

; Now, trap #$B will unprotect the 8K/24K area starting from $3E000.
; This includes the last page of the RAM too, so executing from the
; the ghost space is enabled too. The stack is set up on such way,
; that when the trap #$B is finished, the "rte" will transfer 
; execution to the address $3E000. But, there you will find 
; jmp nx+40000, so the execution continues at the label "nx", now
; in the "ghost space":

h220xtsr_nx:
 move.l (a7)+,$3E002        ; restore the original content at
 move.w (a7)+,$3E000        ;   address $3E000
 lea 20(a7),a7              ; free the stack space
 move.l (a7)+,a0            ; pick up the return address and make
 adda.l #$40000,a0          ;   it "ghost" (very important)
 jmp (a0)                   ; return, but now in the ghost space

h220xtsr_newtrapb:
 dc.b '2TSR' ;signature
h220xtsr_oldtrapb: dc.l 0 ;This is a placeholder for the original trap #$B address.
 cmp.l #$f,d3 ;check if function $f
 bne h220xtsr_callold ;if no, just call the original trap #$B
 cmp.l #$200000,2(a7) ;check if enter_ghost_space
 bcs h220xtsr_alreadyghost ;if yes, do nothing (program execution will be at PC+$80000)
                  ;which is still in the ghost space (ghost of ghost)
 cmp.l a2,a0 ;check if Exec command
 bne h220xtsr_exec ;if yes, special treatement
;The address of the program to execute is stored in a2 by AMS 2.0x.
 cmp.l #$40000,a2 ;check if already in the ghost space
 bcc h220xtsr_alreadyghost ;if yes, do nothing
 add.l #$40000,a2 ;add $40000 to a2 if it is not already in the ghost space
 clr.l d0 ;get the end of the program
 move.w -2(a2),d0
 add.l a2,d0
 subq.l #1,d0
 move.l d0,-(a7)
 move.l a2,-(a7)
h220xtsr_common: ;common for ASM and Exec
 move.l $C8,a0
 move.l EX_patch*4(a0),a0 ;relocate the program again:
 jsr (a0)                 ;call EX_patch without destroying a4
 addq.l #8,a7
h220xtsr_alreadyghost:
 rte
h220xtsr_exec:
 cmp.l a5,a0 ;check if really Exec command
 bne h220xtsr_alreadyghost ;if no, do nothing!!!
;The address of the STR_TAG of the exec string is stored in a2 by AMS 2.0x.
;The program address is stored in a5 by AMS 2.0x.
 add.l #$40000,a5 ;add $40000 to a5 if it is not already in the ghost space
 clr.l d0 ;get the end of the program
 lea.l -1(a2),a1 ;not to change a2 in order to respect the calling convention
h220xtsr_execnext:
 addq.l #1,d0
 tst.b -(a1)
 bne h220xtsr_execnext
 lsr.l #1,d0
 add.l a5,d0
 move.l d0,-(a7)
 move.l a5,-(a7) 
 bra h220xtsr_common
h220xtsr_callold:
 move.l h220xtsr_oldtrapb(PC),-(a7) ;get the original trap #$B address (on the
                                    ;stack)
 rts ;jump to it (from the stack, in order not to destroy any registers)
h220xtsr_endtrapb:

;error and success messages:

h220xtsr_nomemST: dc.b 'ERROR: Not enough memory',0

 EVEN

h220xtsr_skip:
 movem.l (a7)+,a0-a6/d0-d7 ;restore all registers