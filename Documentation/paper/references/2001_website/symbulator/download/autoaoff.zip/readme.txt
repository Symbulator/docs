Auto Alpha-Lock Off for TI-89 AMS 2.01-2.05 by Kevin Kofler - v.1.04
====================================================================

I) Use
This program disables the annoying feature of Advanced Mathematics Software 2
for the TI-89, which automatically enables the alpha-lock (the letter
entering mode) when entering a dialog. I for instance never use this
alpha-lock and always hold alpha when typing, so I am really annoyed by this
feature. My program will allow you to get rid of this annoyance, WITHOUT ANY
modification to the AMS ROM itself (but by installing itself into RAM, like
assembly kernels or AutoClBr; see section IV for details).

II) Installation / Uninstallation

1) Installation:
To install Auto Alpha-Lock Off, simply type autoaoff() from the home screen
and press [ENTER]. Make sure you have uninstalled any previous versions
before installing v.1.04.

2) Uninstallation:
To uninstall Auto Alpha-Lock Off, simply type uninevhk() from the home screen
and press [ENTER]. This uninstaller is called UnInEvHk (uninstall event hook)
because it is already common to 2 programs (Auto Alpha-Lock Off and AutoClBr)
and could in the future uninstall other memory resident (see IV) programs as
well, as long as they follow the same conventions as Auto Alpha-Lock Off.

3) Emergency uninstallation:
Unfortunately, if normal uninstall doesn't work or if your calculator locks
up, you will have to reset your calculator. Press [2nd]+[Left]+[Right]+[ON]
on a TI-89 or [2nd]+[Hand]+[ON] on a TI-92+. This will cause you to LOSE all
data in RAM and on old software versions also in archive. (The newest
Advanced Mathematics Software versions - 2.04 and 2.05 - currently have the
best archive recovery.)
This should NEVER EVEN happen. I'm really sorry if this should happen. Note
that I cannot assume legal responsibility for data loss (see section VI.a).

III) History

Current version:
v.1.04: * Removed a redundant (useless) call to HeapLock in the installer.
        * Recompiled with v.1.02 of my HW2 AMS 2.0x TSR Support, which
          fixes a nasty bug which might cause random crashes or corrupt the
          mathematical functions of the calculator. If you are using HW2
          with AMS 2.0x and WITHOUT HW2Patch, and if you had installed
          v.1.01-1.03 of Auto Alpha-Lock Off, then I strongly recommend you
          to reset your calculator before updating. I am really sorry for
          this. Read h220xtsr.txt for information about how to update
          without resetting (NOT recommended!).

Previous versions:
v.1.00: This version was the first public release.
v.1.01: * Now really runs stable on HW2 with AMS 2.0x and without HW2Patch.
        * Added support for AMS 2.02.
v.1.02: Recompiled with v.1.01 of my HW2 AMS 2.0x TSR Support, a bugfixed
        version which does not install itself on patched HW2, where it is
        not needed.
v.1.03: Fixed an initialization bug (which activated itself when sending
        Auto Alpha-Lock Off to a calculator with AMS 2.04 or 2.05 from one
        with an older version or from 2.04 to 2.05 after running it
        unarchived)

IV) How Auto Alpha-Lock Off works

It is a TSR (terminate but stay resident) program, which installs itself in
a higher zone (at the end) of the RAM (using the HeapAllocHigh function).
This means: it will be active after installation even after returning to the
home screen and it should not consume any system memory (the RAM wich is used
for calculations), which is located the lower RAM zones (at the beginning).
It installs an event hook which captures all events, but without disabling
TI's event handling routine. In case of other installed event hooks, the
Auto Alpha-Lock Off event handler calls them after having processed the
event. The event handler only processes the CM_IDLE event with a special
status parameter corresponding to the automatic alpha-lock feature. It also
checks if the event structure is produced by a dialog. There are some
additional details that I won't explain here. (Read the comments in the
source code if you want to know them.) All other events are simply ignored.
Whenever the automatic alpha-lock event happens to be detected, the event
handler automatically turns alpha-lock off again, thus giving the effect of a
disabled auto alpha-lock. (Note that the event will be detected only when
entering a request in a dialog, but this is a detail and will not affect the
functionality in any way.)
Auto Alpha-Lock Off should NEVER interfere with user triggered alpha-lock or
with the auto alpha-lock in the Catalog and Var-Link dialogs, which don't
accept numbers and symbols but just letters. (If it does, please report it as
described in section V below.)

This program uses and includes my TI-89/92+ Hardware 2.00 AMS 2.0x TSR support
v.1.02 in its installation routine. See h220xtsr.txt for details about it. It
is installed ONLY on HW2 with AMS 2.0x and without HW2Patch.

The program size is about 1300 bytes:
- about 1100 bytes installing routine
- about 200 bytes memory resident routine

V) Bugs

There are currently NO known bugs.
Note that it is normal if Auto Alpha-Lock Off refuses to install itself on
a TI-92+ or on a TI-89 with AMS 1. Those calculators don't have the automatic
alpha-lock feature. (The TI-92+ has no alpha-lock at all.) Thus, I don't see
what my program should do on those calculators, other than wasting a few
bytes of RAM.
If you have to report a bug to me, see section VIII. PLEASE report any bugs
you find, or else I cannot correct them.

VI) License

The following is the minimum of legal sentences I have to write to avoid
getting into trouble:

-----------------------------------------------------------------------------

Kevin Kofler's TI-89 Program License
====================================

This license applies to all TI-89 programs by Kevin Kofler, unless otherwise
stated. Note that CHEMISLV is NOT an exception since the following is a
generalized copy of the CHEMISLV-License (readme point 8).

a.I CAN'T BE HELD RESPONSIBLE FOR ANYTHING! NO WARRANTY!
b.YOU CAN'T SELL MY PROGRAM OR CLAIM IT IS YOURS!
c.IF YOU TRANSMIT ONLY PARTS OF THIS PROGRAM, YOU MUST SAY THAT IT'S A PART
  OF THE (package name) PACKAGE AND ONLY A PART!
d.NORMAL RIGHT APPLIES TO THE THINGS I'VE FORGOTTEN!

-----------------------------------------------------------------------------

If anything is not clear, just ask me for my permission (notably for matters
of distribution on websites and/or modified versions).

VII) Credits

Thanks to:
* Zeljko Juric for documenting some important operating system functions
* Rusty Wagner for the Virtual TI emulator
* Sebastian Reichelt for the TI-GCC IDE (integrated developer environment),
  which was used for this program
* Charlie Gibbs and David Ellsworth for the A68K assembler

VIII) Contact me

Homepage: http://kevinkofler.cjb.net
E-Mail: kevin.kofler@chello.at
