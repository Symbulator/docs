S2S  - Symbolic two ports networks Solver -
version 1 beta 08/16/1999
by Daniele Martini
email: martinid@ftbcc.it
************************************************

S2S is a set of programs which allow you to 
perform a faster analysis of two ports networks
through Symbolic Circuit Simulator (SCS).
S2S requires SCS to be installed in your Ti-89.
************************************************

Syntax:  #par(cir)

where # can be z,y,h,g,a,b depending on which
parameters must be calculated.
cir is the matrix describing the two port
network. To edit circuits use the usual SCS 
syntax.

You NEED to remember to assign:   

        node 0   to   the lower left terminal
        node 1   to   the upper left terminal
        node 2   to   the lower right terminal
        node 3   to   the upper right terminal

                   ___________  
       (1)  o-----I           I-----o  (3)
                  I two ports I
                  I network   I
       (0)  o-----I___________I-----o  (2)



After running the program type #mat to view the
result. Type #mat_ if you wish to have also the 
units of measure displayed.

************************************************
 