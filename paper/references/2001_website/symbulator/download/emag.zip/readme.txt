EMag... Beta version

Author Nevin McChesney
Date 2/21/00

Emag can convert between Cartessian, cylindrical, and spherical coordinates.
It will perform divergence, curl, gradient, laplacian, line integrals, surface integrals
and volume integrals.

All the programs and variables are stored in a folder titled Emag.


In order to use the program, change folder to Emag and type emagmenu() on the home
screen and press enter.  You should see the following screen shot.


Under F1.  crdcnv()  converts any vector or function between any of the coordinate systems
stated above.  crdconv requires a vector input of the form [a,b,c].  where a,b, and c, are
the components of the vector.  To convert a function the format is [function,0,0], this is
style of fxn input is only for crdcnv().


F2
Line calculates the line integral of a fxn along a given path.  
Int(F dot dl) where F is a vector fxn.  
input in the form line([f])
describe the path and limits of integration when prompted

the format is the same for surface and volume integrals.


F3
the programs div, curl, grad, scallap, and veclap
require the vector format described above.
div =divergence of a vector, input [a,b,c]  
curl = curl of a vector, input [a,b,c]
grad = gradient of a vector, input is a fxn, any fxn
scallap = laplacian of a scalar,  input is a fxn
veclap = laplacian of a vector, input [a,b,c]


F4
a few greek variables that are useful


F5
All answers for Emag programs are stored in "result". So to make them easier to see
hit F5 to display result on the home screen command line.


Example
Given C=[0,p,0] in cylindrical, find C in Cartesian

crdcnv([o,p,0]) [enter]
From to dropdown menu select cyl->rect
and vector
when done is displayed F5 [enter]
[-y,x,0]


For F=[y,-x,o] in cartesian, evaluate the line integral F*dl along the path defined by
y=2x and z=4x, between the points (0,0,0) and (1,2,4)

F2 lines([y,-x,0])
choose rect
integration variable x
x initial = 0
x final = 1
y= 2*x
z = 4*x
F5   [enter]
answer is zero

the surface and volume integral fxn are very simmilar to the lines.

Find the Gradient of f= x^2+y^2 in cartesian and cylindrical coordinates.
F3 Grad(x^2 + y^2)
from dropdown menu rect, for cartisian.
F5 [enter]
The gradient in cartesian is [2x,2y,0]

to Find the gradient in cylindrical first convert the fxn to cylindrical
crdcnv([x^2+y^2,0,0])
choose rect->cyl and fxn
grad(result)
choose cyl
F5 [enter]
[2*p,0,0] is the gradient of F in cylindrical form


As my Eloctromagnetics class progresses thru the semister I will attempt to update Emag
with new useful programs.  
This is not fully tested yet, please be patient. I will attempt to eliminate any bugs as they arise.
Please report any problems or advice to mcchen@eecs.ukans.edu.	