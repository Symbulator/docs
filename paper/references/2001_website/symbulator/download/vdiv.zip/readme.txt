vdiv() - Voltage divider resistor solver for TI92+
Doug Burkett
dburkett@infinet.com
1 aug 99


Abstract
--------
This program, vdiv(), solves for values of two resistors in a voltage divider such that the output voltage most closely matches the desired voltage. The significant feature of the program is that the resistors are chosen from a list of available resistors, not from all standard values. This means that the best divider can be made from resistors on hand.

The program also displays some other useful calculated results for the voltage divider.

I welcome comments and criticisms about this program. I can be emailed at dburkett@infinet.com



Disclaimer
----------
The routines and information I provide here are offered without expressed or implied warranty. I am not responsible for any damages of any type you may incur from using this code.

I offer these routines for educational purposes only. I have not thoroughly tested the routines.



Installation
------------
Download and unzip vdiv.zip, which contains these files:

	vdiv.9xp	The main program
	bestr.9xf	A function needed by vdiv()
	reslists.9xl	A list of resistor lists
	rsast.9xm	A list of resistors for demonstration

Create a new folder on the calculator; I suggest the name 'voltdiv'. Download all four files to the folder. vdiv() and bestr() can be archived. reslists and rsast can be archived only if you will not be changing them.
	


Usage
-----
Set the current folder with

	setfold(voltdiv)

Set the mode to APPROX, and set the number display format as you want. I recommend you set the Exponential Format to ENGINEERING, which makes the results easier to interpret.

Execute the program with

	vdiv()

You are first shown a dialog box to select a resistor list, or add or delete lists. Then you are shown a dialog box to enter the circuit parameters. Then, vdiv() finds the best-fit resistors for the desired output voltage and displays the results.

In this section I assume that you have downloaded the demonstration list 'rsast'. You can have more than one list, and add and delete lists, which I describe later. The rsast[] list is actually the values in the Radio Shack resistor assortment #271-312.

You can press ESC at either of the two main dialog boxes to quit the program.

The first dialog box, titled "VDIV CHOOSE LIST", looks like this:

	Use list: RS asst
	Add list: no
	Delete list: no

Press ENTER to accept the current list. A new dialog box, title "VDIV INPUT", is shown:

	V1: 2
	V2: 0
	Vo: 1
	Minimum R1+R2: 0
	Maximum R1+R2: 2E6
	R1 & R2 tol %: 1

vdiv() assumes that the voltage divider consists of two resistors R1 and R2 in series, like this:

	V1---|R1|---*---|R2|---V2

so voltage V1 is applied to R1, and V2 is applied to R2. The output voltage is at the junction of R1 and R2, marked with '*' in the figure. vdiv() also assumes that V1 and V2 are supplied by ideal voltage sources, with source resistances of zero ohms.

Use the dialog box to enter voltage V1 and V2. If R2 is grounded, as is often the case, set V2 = 0. Enter the desired output voltage for Vo.

Set the 'Minimum R1+R2' value to the minimum total resistance you want for the sum of R1 and R2. Similarly, set 'Maximum R1+R2' to the maximum total resistance. For some circuits, performance is determined by the total resistance, so I give you the choice to set the limits. vdiv() will return only solutions that meet these limits.

The item 'R1 & R2 tol %" is set to the percentage tolerance of the resistors to be used. Both resistors must have the same tolerance. This tolerance is used only to calculate the output voltage limits as shown below.

As an example, suppose I need an output voltage of 3.65V from a divider with a 5V supply. I want the divider to draw less than 1mA, so I set the minimum R1+R2 to 5Kohm. I also want the total resistance to be less than 100Kohm, to limit the source impedance. I'll use the Radio Shack resistor assortment, so the tolerance is 5%. I set the parameters as follows:

	V1: 5
	V2: 0
	Vo: 3.65
	Minimum R1+R2: 5000
	Maximum R1+R2: 100000
	R1 & R2 tol %: 5
	
While vdiv() is searching for the best resistors, it shows the best values found so far, on the program I/O screen, like this:

	R1: {R1 value}    R2: {R2 value}   {ratio error}

The {ratio error} is the value that vdiv uses to find the best resistor match. Smaller values indicate a better match. It might take a few seconds for this display to appear, while vdiv() rejects combinations that don't meet the minimum and maximum resistance limits.

After vdiv() checks all the resistor combinations, it shows this output screen:

	R1: 10E3   R2: 27E3
	Vo: 3.6487
	Vo abs err: 1.351E-3
	Vo rel err: 37.023E-3
	Vo limits: 3.5477  3.7451
	Current: 135.135E-6
	R1 power: 182.615E-6
	R2 power: 493.061E-6

Press ENTER to return to the home screen when you are done reviewing the results.

vdiv() found that the best resistors are 10Kohm and 27Kohm. The other results are interpreted as follows:

	Vo: 		The actual output voltage with R1 and R2
	Vo abs err: 	Absolute error; the difference between the actual Vo and the Vo
			I entered
	Vo rel err:	The relative error, in percent
	Vo limits: 	The worst-case output voltage limits, given the resistor tolerance
	Current:	The current through the divider resistors, in amps
	R1 power:	The power dissipated by R1, in watts
	R2 power: 	The power dissipated by R2, in watts.
	
In this case vdiv() found a pretty good solution, with an error of about 1.4mV, but note that the large 5% tolerance of the Radio Shack resistors results in a pretty wide output voltage tolerance.

You can interrupt vdiv() while it is running by pressing any key. vdiv() then shows this dialog:

	VDIV - INTERRUPTED
	Press ENTER to quit,
	or ESC to continue.

If you press ESC, vdiv() continues to run. If you press ENTER, vdiv() shows the results for the best resistors found so far.

If you have a large resistor list, it can take a while for vdiv() to check all the possible combinations. Further, if your list contains resistor pairs which differ by orders of magnitude, the vdiv() will return only one of these pairs. For example, if the list contains values of 18K, 27K, 180K and 270K, and the best match involves these values, vdiv() will return only 18K and 27K, or 180K and 270K, depending on the input parameters.

If vdiv() finds an exact solution during the search, it stops searching and immediately displays the result. While this can save time, it does mean that there may be other exact solutions that are not found.



Using resistor lists
--------------------
vdiv() supports multiple resistor lists, because I needed them. For example, you might have one set of resistors in your lab, and another set of resistors for production use. By setting up two lists, you can choose which one to use.

vdiv() provides minimal features for managing the resistor lists. These features are provided on the first dialog box shown when running vdiv(). You can choose a list, add a new list, or delete an existing list.

A resistor list is a single-column matrix of all the resistor values, sorted in ascending order with no duplicates. This is important! If the list is not in ascending order, or contains duplicates, this will confuse the binary search algorithm that vdiv() uses.

To add a new resistor list:

	Use the 89/92+ matrix editor to create a new matrix with 1 column, and as many 
	rows as you have resistors. Enter the resistor values. Use the matrix editor to 	sort the matrix, and review it to make sure that there are no duplicates.

	Run vdiv(). Choose 'Add list', select Yes, and press ENTER. You are shown
	another dialog box:

		List description:
		Variable name:

	The List description you enter will be shown in the Use List dialog, and the 	variable name is the name of the matrix you created. Enter these and press 	ENTER, 	or press ESC if you change your mind.

	vdiv() checks to make sure the list exists, and is a matrix. If not, you are
	shown an error message, and given the chance to try again.

To delete an existing resistor list:

	Run vdiv(), choose 'Delete list', select Yes, and press enter. You are shown a 
	dialog box:

		Delete list:

	Choose the list to delete and press ENTER. If you change your mind, press ESC to 
	quit without deleting any lists.

	This feature really deletes the list from memory, without any additional 
	confirmation, so be sure you really want to delete it!

If you use Delvar of Var-link to delete a list, you will remove it from memory, but vdiv() will think that it still exists, which will result in an error if you subsequently try to use it.



Error handling
--------------
vdiv() implements some minimal error handling to avoid problems. You may get these error messages:


WARNING
No resistor lists available
Use ADD option to add a list

	You'll get this message if vdiv() can't find the variable it uses (reslists) to
	keep track of the resistor lists. You'll automatically be taken to the 'Add
	list' dialog box, to add a list.


VDIV ERROR
You must enter names for
the description and the variable

	You'll get this message if you try to add a new list, but don't enter anything 
	for the description or variable name.


VDIV ERROR
{name} doesn't exist or
is not a matrix.

	Here, {name} is the variable name you entered when adding a new list. vdiv() 
	checks to make sure the list exists and is a matrix.


VDIV ERROR
V1 must be > V2

	You'll get this error message if you enter the same voltages for V1 and V2, or 	you enter voltages such that V2 is greater than V1.


VDIV ERROR
Vo must be < V1 and > V2

	The output voltage must be between the divider supply voltages


VDIV ERROR
Min R1+R2 must be less than max R1+R2

	The minimum total resistance must be less than the maximum total resistance. 


VDIV ERROR
Min R1+R2 and max R1+R2 must be >0

	You'll see this message if you accidentally enter a negative number for either 	limit.


VDIV ERROR
No unique solution if
V1+V2=2Vo. Use any two
equal-value resistors.

	If the sum of the input voltages is twice the output voltage, than any two 	equal-value resistor will satisfy this criteria, and you don't really need 	vdiv().


VDIV ERROR
Tolerance must be > 0

	The resistor tolerance must be greater than zero, or the output voltage limits 	won't be correctly calculated.


Comments
--------
The general expression for the voltage divider is

	Vo = (V1*R2 + V2*R1)/(R1 + R2)

The goal is to find R1 and R2 to minimize the output voltage error. While we could blindly just try every possible R1 and R2, this wastes time unnecessarily. Instead, I take advantage of the properties of the voltage divider, as described here.

Let R2 = m*R1, then m = R2/R1, and so

	Vo = (m*V1 + V2)/(m + 1)

and

	m = (Vo - V2)/(V1 - Vo)

For convenience later, let n = 1/m = (V1 - Vo)/(Vo - V2). We can show that

	n > 1   when    Vo < (V1 + V2)/2

Since Vo, V1 and V2 are all known parameters, we know that 'n' will be greater than 1 or less than 1. (If n = 1, then R1 = R2 and there is no unique solution). Since n = R1/R2, we know from the input parameters if R1 > R2 or R1 < R2. This considerably limits the search.

We can express the output voltage in terms of 'n', as well:

	Vo = (V1 + n*V2)/(n + 1)

It is always useful to know the output voltage limits, given the resistor tolerance. We can find the conditions for these limits by finding the first derivative

	dVo/dn = (V2 - V1)/(n + 1)^2

So the output voltage will be at the maximum limit when 'n' is at its minimum value, and vice versa. Since n = R1/R2, we have

	maximum Vo when R1 is minimum and R2 is maximum,
	minimum Vo when R1 is maximum and R2 is minimum


	
