Symbulator
by Roberto Perez-Franco
Version Q built 021118

Symbulator requires DiffEq by Lars Frederiksen.
Both Symbulator and DiffEq can be obtained in Symbulator's official website, http://paxm.org/symbulator which is hosted by Pax Movement.

Symbulator invites you to work for peace only. Join Pax Movement -> paxm.org

You must load to your calculator the following files: 

1) From sq.zip: the file sq.89g (main programs of Symbulator). When loaded to your calculator this group will create a folder called 'sq' with several files inside, including a program called install(). This program will archive the Symbulator files in ROM in such a way that the best speed is achieved.

2) From diffeq.zip, the file diff206.89g. When loaded to your calculator this group will create a folder called 'dif' with several files inside, including a program called install(). This program will archive the DiffEq files in ROM in such a way that the best speed is achieved.

Warning! Do not change the names of any of these files. By doing so, you may turn them useless.
 
Very important! Symbulator and DiffEq are very fast programs. But to enjoy their speed you need to archive the files properly and keep enough free memory (around 180KB) in the RAM. Although, you should not archive these files without using them before, or the calculator will have to compile them every time you run them. When you install Symbulator and DiffEq in your TI-89 or your TI-92+, follow these procedures:

Archiving DiffEq files on TI-89 or equivalent calculator:

After loading the diff206.89g to your calculator, run the install() program. It will prepare and archive DiffEq files in your ROM. Just execute following command from the command line:

dif\install()

The install program install() and it's sub program archive() can be deleted after installation. Keep them if you plan to pass the program to a friend using the linking cable.

Archiving Symbulator files on TI-89 or equivalent calculator:

After loading the sq.89g to your calculator, run the install() program. It will prepare and archive Symbulator files in your ROM. Just execute following command from the command line:

sq\install()

If you plan to pass the program to a friend using the linking cable, you should keep this program. Just keep it archived...

Archive sq\install
 
To uninstall Symbulator, use:

sq\uninstal()

Symbulator documentation is huge, thus it is not included here. You have to read it online at the official website, which URL is given at the start of this file. Here you can also get the latest Symbulator version and several other great programs. Share Symbulator with your classmates freely! If you use Symbulator, please let me know so. Send me an email at symbulator@perez-franco.com and tell me what you think of it. As a Symbulator user, you are invited to work for peace, and join Pax Movement, which is a pacifist movement for engineers. Engineers should always work for peace, never for war.
Change the rules... join Pax! http://paxm.org

Enjoy! :o)

- Roberto Perez-Franco
http://perez-franco.com
Symbulator author & Pax Movement founder

Symbulator and everything related to it is (c) Roberto Perez-Franco 1999-2002
DiffEq and everything related to it is (c) Lars Frederiksen 1999-2002